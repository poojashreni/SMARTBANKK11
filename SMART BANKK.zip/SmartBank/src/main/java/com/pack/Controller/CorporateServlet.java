package com.pack.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.Dao.CorporateDao;
import com.pack.Model.Corporate;




/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/CorporateServlet")
public class CorporateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	CorporateDao corporateDao=new CorporateDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CorporateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println(action);
		switch(action)
		{
		case "add":
			insert(request,response);
		    break;
		case "update":
			update(request,response);
			break;
		case "delete":
			delete(request,response);
		    break;
//		case "view":
//			view(request,response);
//			 break;
//		}
		} 
	}
    
    protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Corporate  corporate=new Corporate();
  	  
		/*
		 * corporate.setCorporateId(request.getParameter("corporate"));
		 */    	
    	corporate.setCorporateName(request.getParameter("corporateName"));
    	corporate.setAddress(request.getParameter("address"));
    	corporate.setPhoneNumber(request.getParameter("phoneNumber"));
  			 
    	 
    	  int i = corporateDao.add(corporate);
    	    
    	    if(i>0){
    	    	response.sendRedirect("corporatesuccess.jsp");
    	    }  
    	    	   else{ response.sendRedirect("corporatefailure.jsp");
    	    	 
    	    	}
    	    } 
    	    
    
    protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 
		 
		
    	Corporate  corporate=new Corporate();
		  System.out.println("in update of servlet");
		  corporate.setCorporateId(Integer.parseInt(request.getParameter("corporate_id")));
		  corporate.setAddress(request.getParameter("address"));
		  corporate.setPhoneNumber(request.getParameter("phoneNumber"));
		  
		  System.out.println("in servlet "+ corporate.getCorporateId()+" "+ corporate.getAddress()+" "+ corporate.getPhoneNumber());
		  
		  int i = corporateDao.update(corporate);
  	    
  	    if(i>0){
  	    	response.sendRedirect("updatecorpsuccess.jsp");
  	    }  
  	    	   else{ response.sendRedirect("updatecorpfailure.jsp");
  	    	 
  	    	}
  	    } 
    
	 
	 
	
    
    protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   	 
    	 int id=Integer.parseInt(request.getParameter("id"));
    	
    	
    	 System.out.println("id is "+id);
    	int i=corporateDao.delete(id);
    	
    	 if(i>0){
   	    	response.sendRedirect("deletecorpsuccess.jsp");
   	    }  
   	    	   else{ response.sendRedirect("deletecorpfailure.jsp");
   	    	 
   	    	}
   	    } 
     
    	 
    		 

    }
    

	