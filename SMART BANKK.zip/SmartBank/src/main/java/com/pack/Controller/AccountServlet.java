package com.pack.Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.Dao.AccountDao;
import com.pack.Model.Account;


/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	AccountDao accDao = new AccountDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		System.out.println(action);
		switch(action)
		{
		case "add":
			add(request,response);
		    break;
		case "delete":
			delete(request,response);
			break;
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    Account acc = new Account();
	    System.out.println("in add of Account servlet");
		acc.setCor_id(Integer.parseInt(request.getParameter("cor_id")));
		acc.setAccountno(Long.parseLong(request.getParameter("Accountno")));
		acc.setAccountName(request.getParameter("AccountName"));
		acc.setBranch(request.getParameter("Branch"));
		acc.setCurrency(request.getParameter("Currency"));
		acc.setAvailableBalance(Long.parseLong(request.getParameter("AvailableBalance")));
				 
		int i = accDao.save(acc);
		if(i>0){
			response.sendRedirect("viewAccounts.jsp");
		}else{ 
			response.sendRedirect("addAccount-failure.jsp");
		}
	}
	
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		  Long id=Long.parseLong(request.getParameter("Accountno"));
		  Account acc=new Account(); 
		  System.out.println("in delete of Account servlet");
		  acc = accDao.getRecordById(id);
		  int i=accDao.delete(acc);
		  if(i>0){
			  response.sendRedirect("deleteAccount-success.jsp");
		  }else{
			  response.sendRedirect("deleteAccount-failure.jsp"); 
		  }
			 	
	}

}
