package com.pack.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.pack.Model.Account;


public class AccountDao {
	public int save(Account acc){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into Account(cor_id,Accountno,AccountName,Branch,Currency,AvailableBalance)  values(?,?,?,?,?,?)");
		 
			ps.setInt(1,acc.getCor_id());
			ps.setLong(2,acc.getAccountno());
			ps.setString(3,acc.getAccountName());
		 	ps.setString(4,acc.getBranch());
			ps.setString(5,acc.getCurrency());
			ps.setLong(6,acc.getAvailableBalance());
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;	
	}
	
	public int delete(Account acc){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("delete from Account where Accountno=?");
			ps.setLong(1,acc.getAccountno());
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	public List<Account> getAllRecords(){
		List<Account> list=new ArrayList<Account>();
		
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("select * from Account order by cor_id");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Account acc=new Account();
				acc.setCor_id(rs.getInt("cor_id"));
				acc.setAccountno(rs.getInt("Accountno"));
				acc.setAccountName(rs.getString("AccountName"));
			 	acc.setBranch(rs.getString("Branch"));
			 	acc.setCurrency(rs.getString("Currency"));
				acc.setAvailableBalance(rs.getInt("AvailableBalance"));
				list.add(acc);
			}
		}catch(Exception e){System.out.println(e);}
		return list;
	}
	
	public Account getRecordById(long acNo){
		Account acc=null;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("select * from Account where Accountno=?");
			ps.setLong(1,acNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				acc=new Account();
				acc.setCor_id(rs.getInt("cor_id"));
				acc.setAccountno(rs.getInt("Accountno"));
				acc.setAccountName(rs.getString("AccountName"));
			 	acc.setBranch(rs.getString("Branch"));
			 	acc.setCurrency(rs.getString("Currency"));
				acc.setAvailableBalance(rs.getInt("AvailableBalance"));
			}
		}catch(Exception e){System.out.println(e);}
		return acc;
	}
}
