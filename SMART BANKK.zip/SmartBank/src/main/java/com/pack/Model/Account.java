package com.pack.Model;

public class Account {
	public int cor_id;
	private long Accountno,AvailableBalance;
	private String AccountName,Branch ,Currency;
	public int getCor_id() {
		return cor_id;
	}
	public void setCor_id(int cor_id) {
		this.cor_id = cor_id;
	}
	public long getAccountno() {
		return Accountno;
	}
	public void setAccountno(long accountno) {
		Accountno = accountno;
	}
	public long getAvailableBalance() {
		return AvailableBalance;
	}
	public void setAvailableBalance(long availableBalance) {
		AvailableBalance = availableBalance;
	}
	public String getAccountName() {
		return AccountName;
	}
	public void setAccountName(String accountName) {
		AccountName = accountName;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	
	
}
