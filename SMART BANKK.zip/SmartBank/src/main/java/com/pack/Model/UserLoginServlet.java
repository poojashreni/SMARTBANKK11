package com.pack.Model;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pack.Controller.UserLoginBean;
import com.pack.Dao.UserLoginDao;


@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String UserId=request.getParameter("UserId");
		String UserPassword=request.getParameter("UserPassword");
		
		HttpSession session=request.getSession();
		session.setAttribute("UserId", UserId);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		//after retrieving data from jsp it first goes to UserLoginDao.FirstLogin method
		UserLoginBean userloginBean=new UserLoginBean();
		userloginBean.setUserId(UserId);
		userloginBean.setOldPassword(UserPassword);
		
		UserLoginBean userloginBean1=new UserLoginBean();
		userloginBean1.setUserId(UserId);
		userloginBean1.setNewPassword(UserPassword);
		UserLoginDao loginDao=new UserLoginDao();
		
		//if it is true then redirects to changepassword page
		if(loginDao.FirstLogin(userloginBean))
			
		{
			response.sendRedirect("changepassword.jsp");
		}
		
		//else goes to UserLoginDao.LoginDAO and validates if true redirects to success login page
		else if(loginDao.LoginDAO(userloginBean1)) {
			
			
			 response.sendRedirect("bank1.jsp");
				
		}
		//above both are false then includes invalid details statement in userlogin page.
		else {
			out.println("Invalid Id and Password");
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/userlogin.jsp");
			rd.include(request,response);
		}
	}

}
